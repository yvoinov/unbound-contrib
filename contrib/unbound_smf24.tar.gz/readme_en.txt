=============================================================
unbound SMF Installation & Remove   (C) 2007-2023 Yuri Voinov
=============================================================

***  WARNING!  The  package  is configured by default to run
unbound, installed in /usr/local!

This  set  of  scripts is designed to install and remove the
SMF service for unbound daemon on Sun Solaris 10 and above.

All  necessary  prerequisites  required  to  run the unbound
service, according to the configuration guide (excluding the
configuration  of  unbound  itself) are performed during the
installation  of  the  service,  removing  the  SMF  service
removes  all scripts and unregisters the unbound service and
stops it.

To activate unbound SMF, follow these steps:
------------------------------------------------------------

1. Install unbound and all required libraries if you haven't
already.

2. Configure unbound by editing unbound.conf.

3.  Run  the  unbound_smf_inst.sh script, which will perform
all  necessary  prerequisites  and post-installation actions
and install the unbound SMF service.

4. Run the svcadm enable unbound command to enable and start
the unbound service.

To  deactivate  and  remove  the unbound SMF service, follow
these steps:
------------------------------------------------------------

1.Run  the  unbound_smf_rmv.sh  script. The script stops all
running  unbound  processes,  unregisters  the  SMF service,
completely  removes  the  unbound  SMF  and  rolls  back the
operations   previously   performed  when  the  service  was
activated.

***  Note:  Removing the unbound SMF service does not remove
the installed unbound software.

Archive contains:

init.unbound        - Unbound SMF Control Method
unbound.xml         - Unbound SMF Service Manifest
readme_ru.txt         - ���� ���� (Russian)
readme_en.txt         - This file (English)
unbound_smf_inst.sh    - Unbound SMF Installation Script
unbound_smf_rmv.sh     - Unbound SMF Removal Script

=============================================================
unbound SMF Installation & Remove   (C) 2007-2023 Yuri Voinov
=============================================================